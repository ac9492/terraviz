Files for the projectors
========================

4 projectors, as the install describes them.

Written by sphere-sim. Every file here describes the calibration the software
currently believes, which is what an operator loads — not the ground truth the
simulator holds, which no real dome has.

warp/<projector>.data
---------------------
  warp/P1.data
  warp/P2.data
  warp/P3.data
  warp/P4.data

A Bourke warp-and-blend mesh per lit projector: five columns per vertex, the
displacement and the blend weight together. This carries the full correction,
including the part an SOS alignment file cannot.

layout.json
-----------
  layout.json

Where each warp mesh goes. A Bourke file cannot say which part of the display
it drives, and a mesh drawn into the wrong part still draws a plausible
picture, so nothing on the sphere would say the file was misread. Pair each
mesh with its viewport here, by its "mesh" path, and never by the projector's
name: a name is not a position, and two rigs can give one name two different
places. This file is for whatever loads the meshes. It is not an install
target, so restore/ neither covers it nor counts it.

- "format": sphere-sim/projector-layout@1. Anything else is a different
format; do not read it as this one.
- "origin": bottom-left. A viewport's y counts UP from the bottom of the
framebuffer, as SOS's projectorInfo(viewport) does. A screen that counts rows
down from the top puts the viewport's top edge at 1 - y - h of its height.
- "framebuffer": the one display every viewport divides, width and height in
pixels. Check yours against it before drawing: a display of another size
resamples every mesh and one of another shape stretches it, and neither looks
wrong on the sphere.
- "surface" and "rotationOffsetDeg": what u and v address. "sphere" is the
equirectangular map, and the sphere's rotation, in degrees, has already been
taken off u: do not apply it again. "mesh" is the model's own UV set, which
has no rotation, so the field is null.
- "projectors": one entry per mesh in warp/, in the same order, and no others.
"viewport" is x, y, w and h as fractions of the framebuffer, exactly as the
calibration holds them. Draw "mesh" into that rectangle.

alignment/<projector>.alignment
-------------------------------
  alignment/P1.alignment
  alignment/P2.alignment
  alignment/P3.alignment
  alignment/P4.alignment

Lossy on purpose, four ways: no blend column at all, nine control points for
the whole frame, computed from the true rig this simulator has and a real dome
does not, and a format read off one sample file. Not a replacement for the
Bourke mesh — it is the same correction made testable on the software already
running the sphere.

local_sos_config.json
---------------------
No local_sos_config.json is included: none was loaded. This tool patches the
config you give it rather than writing one from scratch, so that every setting
it does not understand survives untouched. Load your site config on the page
and export again to get one.

restore/
--------
  restore/MANIFEST.txt

This is not a restore point. 1 of 8 files the archive installs can be put back
from copies travelling with it. The 3 Bourke warp-and-blend meshes and 4 SOS
projector alignment files are generated rather than patched, so the page has
never seen whatever is at those paths on your sphere: if a file is there,
installing replaces it and nothing here brings it back. Load them on this page
and a copy travels in the archive; until you do, copying them somewhere safe
by hand is the only way back. A restore point that covers some of what it
overwrote is worse than none, because it is the one that makes you brave. See
restore/MANIFEST.txt for which files are covered and which are not.
