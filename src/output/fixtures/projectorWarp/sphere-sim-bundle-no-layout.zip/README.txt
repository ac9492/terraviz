Files for the projectors
========================

4 projectors, as the install describes them.

Written by sphere-sim. Every file here describes the calibration the software
currently believes, which is what an operator loads — not the ground truth the
simulator holds, which no real dome has.

warp/<projector>.data
---------------------
  warp/P1.data
  warp/P2.data
  warp/P3.data
  warp/P4.data

A Bourke warp-and-blend mesh per lit projector: five columns per vertex, the
displacement and the blend weight together. This carries the full correction,
including the part an SOS alignment file cannot.

layout.json
-----------
No layout.json is included: it places warp meshes, and it is written only
beside them, from the same rig. Without it, nothing here says which part of
the display a mesh drives. Do not pair one with a part by its projector's name
instead, because a name is not a position.

alignment/<projector>.alignment
-------------------------------
  alignment/P1.alignment
  alignment/P2.alignment
  alignment/P3.alignment
  alignment/P4.alignment

Lossy on purpose, four ways: no blend column at all, nine control points for
the whole frame, computed from the true rig this simulator has and a real dome
does not, and a format read off one sample file. Not a replacement for the
Bourke mesh — it is the same correction made testable on the software already
running the sphere.

local_sos_config.json
---------------------
No local_sos_config.json is included: none was loaded. This tool patches the
config you give it rather than writing one from scratch, so that every setting
it does not understand survives untouched. Load your site config on the page
and export again to get one.

restore/
--------
  restore/MANIFEST.txt

This is not a restore point. 1 of 8 files the archive installs can be put back
from copies travelling with it. The 3 Bourke warp-and-blend meshes and 4 SOS
projector alignment files are generated rather than patched, so the page has
never seen whatever is at those paths on your sphere: if a file is there,
installing replaces it and nothing here brings it back. Load them on this page
and a copy travels in the archive; until you do, copying them somewhere safe
by hand is the only way back. A restore point that covers some of what it
overwrote is worse than none, because it is the one that makes you brave. See
restore/MANIFEST.txt for which files are covered and which are not.
